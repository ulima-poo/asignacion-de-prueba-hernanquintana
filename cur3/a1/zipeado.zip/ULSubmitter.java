package com.jsatch.ulsub;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;
import org.apache.commons.io.IOUtils;
import org.kohsuke.github.GHContentUpdateResponse;
import org.kohsuke.github.GHRepository;
import org.kohsuke.github.GitHub;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ULSubmitter {
    private GHRepository mRepo;
    private File mOutputFileH;

    public void connect(){
        try {
            GitHub github = GitHub.connectUsingPassword("hdquintana@gmail.com", "Bar0njoe");
            //GHOrganization org = github.getOrganization("ul-poo");
            mRepo = github.getRepository("ulima-poo/asignacion-de-prueba-hernanquintana");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void compressFiles(){
        try {
            ZipFile zipFile = new ZipFile("zipeado.zip");
            ZipParameters parameters = new ZipParameters();
            parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
            parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_ULTRA);


            Files.walk(Paths.get("./"))
                    .filter(Files::isRegularFile)
                    .forEach((archivo)->{
                        File inputFileH = new File(archivo.toString());
                        try {
                            zipFile.addFile(inputFileH, parameters);

                        } catch (ZipException e) {
                            e.printStackTrace();
                        }
                    });
            mOutputFileH = new File("zipeado.zip");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ZipException e) {
            e.printStackTrace();
        }

    }

    public void upload(){
        try {
            GHContentUpdateResponse resp =
                    mRepo.createContent(IOUtils.toByteArray(new FileInputStream(mOutputFileH)), "asignacion prueba 3", "cur3/a1/zipeado.zip");
            System.out.println(resp.getCommit().getSHA1());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        ULSubmitter ulsub = new ULSubmitter();
        ulsub.connect();
        ulsub.compressFiles();
        ulsub.upload();

        //ulsub.compressFiles();
    }
}
